# Changelog

## 0.2.5 — 2026-10-16

### Fixed
- 手机上传航线时，多条进度遥测、诊断日志及成功回执可能在一次 TCP 读取内到达。Node 中继逐条让出事件循环处理，避免合法突发触发 `inbound-overflow` 断连并丢失上传回执；原有队列上限与溢出保护保持不变。

## 0.2.2 — 2026-10-16

### Added
- Node 与 desktop 入口提供局域网自动发现广播及持久电脑身份，供非 Electron 宿主接线。

### Fixed
- 合并 RTMP 握手前断连清理修复，保留原有 DJI 时间戳回绕与播放时间线修复。
- 修复 desktop CommonJS 包内 `createRequire` 的模块路径，确保 Node ESM 与 CommonJS 宿主均可加载。

## 0.2.1 — 2026-10-15

### Added
- 控制网关放行 `pairing.start` 与 `pairing.stop`，和桌面版中继一样把对频命令交给手机。
- `./desktop` 导出桌面版应用、界面网关和图传端口，网站可以跑同一套飞机操作。

## 0.2.0 — 2026-10-15

### Added
- `camera.photo.fetch` 的照片进度从手机中继转发到浏览器 `onPhotoProgress`。
- 命令上的 `timeoutMs` 会同时延长浏览器等待和中继命令超时，照片回传不再被 35 秒控制超时打断。

## 0.1.0 — 2026-10-07

### Added
- Vue 3 与 React 18/19 共用的设备客户端和订阅封装。
- Node 安卓中继监听与浏览器控制网关，复用 v1 协议。
- ESM、CommonJS、TypeScript 声明和独立 npm 安装包。
- 配对状态、设备设置、飞行、航线、直播、媒体与照片业务的按需导入入口。
- 会话保护、连接恢复、命令超时、二进制任务上传与安装包/浏览器验证。
